# Minty

Is your card mint? Find out instantly.

AI-powered Pokemon card grading app built with Expo, Supabase, and Claude AI.

## Setup

1. `bun install`
2. Copy `.env.example` to `.env` and fill in your keys
3. `bun start`

## Environment Variables

- `EXPO_PUBLIC_SUPABASE_URL` — Supabase project URL
- `EXPO_PUBLIC_SUPABASE_ANON_KEY` — Supabase anon key
- `EXPO_PUBLIC_ANTHROPIC_API_KEY` — Anthropic API key (native builds)
- `ANTHROPIC_API_KEY` — Anthropic API key (server-side API route)

## Build & Ship

```bash
eas build --platform ios --profile production
eas submit --platform ios
```
