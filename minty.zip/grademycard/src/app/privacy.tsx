import { View, Text, ScrollView, Pressable } from "react-native";
import { useRouter } from "expo-router";
import { Image } from "expo-image";
import { T } from "@/lib/theme";

const LAST_UPDATED = "March 8, 2026";

export default function PrivacyScreen() {
  const router = useRouter();

  return (
    <View style={{ flex: 1, backgroundColor: T.bg }}>
      {/* Header bar */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 20,
          paddingTop: 56,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: T.borderSubtle,
        }}
      >
        <Text style={{ fontSize: 18, fontWeight: "700", color: T.text }}>
          Privacy Policy
        </Text>
        <Pressable
          onPress={() => router.back()}
          hitSlop={12}
          style={{
            width: 30,
            height: 30,
            borderRadius: 15,
            backgroundColor: T.surface,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Image
            source="sf:xmark"
            style={{ width: 12, height: 12, tintColor: T.textSecondary }}
          />
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={{ padding: 24, gap: 20, paddingBottom: 60 }}
      >
        <Text style={{ fontSize: 12, color: T.textTertiary }}>
          Last updated: {LAST_UPDATED}
        </Text>

        <Section title="1. Information We Collect">
          We collect information you provide directly: email address (if you
          create an account), card images you upload for grading, and usage data
          such as scan counts and preferences. When using third-party
          authentication (Google, Apple), we receive your name and email from
          those providers.
        </Section>

        <Section title="2. How We Use Your Information">
          Your information is used to provide and improve the grading service,
          manage your account and subscription, save your graded card
          collection, and communicate important service updates. Card images
          are sent to AI processing services (Anthropic) solely for grade
          prediction.
        </Section>

        <Section title="3. Data Storage">
          Account data and card records are stored securely using Supabase
          (cloud-hosted PostgreSQL). Card images are stored in encrypted cloud
          storage. Local device storage is used for offline caching and
          preferences.
        </Section>

        <Section title="4. Third-Party Services">
          We use the following third-party services: Supabase for
          authentication and database storage, Anthropic (Claude AI) for card
          image analysis, Apple for payment processing, and Google for optional
          OAuth sign-in. Each service is subject to its own privacy policy.
        </Section>

        <Section title="5. Data Sharing">
          We do not sell your personal information. We share data only with the
          third-party services listed above as necessary to provide the App's
          functionality. We may disclose information if required by law.
        </Section>

        <Section title="6. Data Retention">
          Your account data is retained as long as your account is active. Card
          images and grade data are retained until you delete them or your
          account. You can delete individual cards from within the App or
          request full account deletion by contacting us.
        </Section>

        <Section title="7. Your Rights">
          You have the right to access, correct, or delete your personal data.
          You can export your card collection data. You can delete your account
          and all associated data at any time. To exercise these rights,
          contact us at support@minty.app.
        </Section>

        <Section title="8. Children's Privacy">
          The App is not directed at children under 13. We do not knowingly
          collect information from children under 13. If you believe we have
          collected information from a child under 13, please contact us
          immediately.
        </Section>

        <Section title="9. Security">
          We implement industry-standard security measures including encrypted
          data transmission (TLS), secure cloud storage, and authentication
          best practices. However, no method of electronic storage is 100%
          secure.
        </Section>

        <Section title="10. Changes to This Policy">
          We may update this Privacy Policy from time to time. We will notify
          you of significant changes through the App or via email.
        </Section>

        <Section title="11. Contact">
          For privacy-related questions, contact us at
          support@minty.app.
        </Section>
      </ScrollView>
    </View>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <View style={{ gap: 8 }}>
      <Text style={{ fontSize: 15, fontWeight: "700", color: T.text }}>
        {title}
      </Text>
      <Text
        style={{
          fontSize: 14,
          color: T.textSecondary,
          lineHeight: 21,
        }}
      >
        {children}
      </Text>
    </View>
  );
}
