import { useState, useRef } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  useWindowDimensions,
  NativeScrollEvent,
  NativeSyntheticEvent,
} from "react-native";
import { useRouter } from "expo-router";
import { Image } from "expo-image";
import * as Haptics from "expo-haptics";
import { markOnboardingSeen } from "@/lib/storage";
import { T } from "@/lib/theme";

const STEPS = [
  {
    icon: "sf:camera.fill",
    title: "Photograph Your Card",
    description:
      "Place your card on a dark, flat surface with even lighting. Use the camera or upload an existing photo.",
    tips: [
      "Avoid glare and shadows",
      "Keep the card flat and centered",
      "Use natural daylight when possible",
    ],
  },
  {
    icon: "sf:wand.and.stars",
    title: "AI Analysis",
    description:
      "Our AI evaluates your card across all four PSA grading criteria — centering, corners, edges, and surface condition.",
    tips: [
      "Higher quality photos = more accurate grades",
      "Fill the entire frame with the card",
      "Hold the camera steady",
    ],
  },
  {
    icon: "sf:chart.bar.fill",
    title: "Get Your Grade",
    description:
      "Receive a predicted PSA grade (1-10) with a detailed breakdown and tips on how to improve your card's grade potential.",
    tips: [
      "3 free scans per day",
      "Save favorites to track your best cards",
      "Use tips to decide which cards to submit",
    ],
  },
];

export default function OnboardingScreen() {
  const router = useRouter();
  const { width } = useWindowDimensions();
  const [currentStep, setCurrentStep] = useState(0);
  const scrollRef = useRef<ScrollView>(null);

  const handleScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const page = Math.round(e.nativeEvent.contentOffset.x / width);
    setCurrentStep(page);
  };

  const handleNext = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    if (currentStep < STEPS.length - 1) {
      scrollRef.current?.scrollTo({
        x: (currentStep + 1) * width,
        animated: true,
      });
    } else {
      await markOnboardingSeen();
      router.back();
    }
  };

  const handleSkip = async () => {
    await markOnboardingSeen();
    router.back();
  };

  return (
    <View style={{ flex: 1, backgroundColor: T.bg }}>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "flex-end",
          padding: 16,
          paddingTop: 60,
        }}
      >
        <Pressable onPress={handleSkip}>
          <Text
            style={{
              fontSize: 16,
              color: T.textSecondary,
              fontWeight: "500",
            }}
          >
            Skip
          </Text>
        </Pressable>
      </View>

      <ScrollView
        ref={scrollRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
      >
        {STEPS.map((step, index) => (
          <View
            key={index}
            style={{
              width,
              paddingHorizontal: 32,
              justifyContent: "center",
              alignItems: "center",
              gap: 24,
            }}
          >
            <View
              style={{
                width: 100,
                height: 100,
                borderRadius: 50,
                backgroundColor: T.accentLight,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Image
                source={step.icon}
                style={{ width: 44, height: 44, tintColor: T.accent }}
              />
            </View>
            <Text
              style={{
                fontSize: 28,
                fontWeight: "800",
                color: T.text,
                textAlign: "center",
              }}
            >
              {step.title}
            </Text>
            <Text
              style={{
                fontSize: 16,
                color: T.textSecondary,
                textAlign: "center",
                lineHeight: 24,
              }}
            >
              {step.description}
            </Text>
            <View style={{ gap: 12, width: "100%" }}>
              {step.tips.map((tip, i) => (
                <View
                  key={i}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 12,
                    padding: 14,
                    borderRadius: 12,
                    borderCurve: "continuous",
                    backgroundColor: T.surface,
                    borderWidth: 1,
                    borderColor: T.borderSubtle,
                  }}
                >
                  <Image
                    source="sf:checkmark.circle.fill"
                    style={{
                      width: 20,
                      height: 20,
                      tintColor: T.success,
                    }}
                  />
                  <Text
                    style={{ fontSize: 15, color: T.text, flex: 1 }}
                  >
                    {tip}
                  </Text>
                </View>
              ))}
            </View>
          </View>
        ))}
      </ScrollView>

      <View
        style={{
          padding: 24,
          paddingBottom: 48,
          gap: 16,
          alignItems: "center",
        }}
      >
        {/* Dots */}
        <View style={{ flexDirection: "row", gap: 8 }}>
          {STEPS.map((_, i) => (
            <View
              key={i}
              style={{
                width: i === currentStep ? 24 : 8,
                height: 8,
                borderRadius: 4,
                backgroundColor:
                  i === currentStep ? T.accent : T.surfaceHover,
              }}
            />
          ))}
        </View>

        <Pressable
          onPress={handleNext}
          style={({ pressed }) => ({
            backgroundColor: T.accent,
            paddingVertical: 16,
            paddingHorizontal: 48,
            borderRadius: 14,
            borderCurve: "continuous",
            width: "100%",
            alignItems: "center",
            opacity: pressed ? 0.85 : 1,
            boxShadow: "0 4px 20px rgba(211,47,47,0.35)",
          })}
        >
          <Text style={{ fontSize: 17, fontWeight: "700", color: "white" }}>
            {currentStep === STEPS.length - 1 ? "Get Started" : "Next"}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}
