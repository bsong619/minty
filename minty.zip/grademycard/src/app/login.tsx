import { useState, useRef } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { AUTH_FLOW_KEY } from "./_layout";
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  KeyboardAvoidingView,
  ActivityIndicator,
  Animated,
  Alert,
  Platform,
} from "react-native";
import { useRouter } from "expo-router";
import { Image } from "expo-image";
import * as Haptics from "expo-haptics";
import {
  signInWithEmail,
  signUpWithEmail,
  signInWithGoogle,
  signInWithApple,
  resetPassword,
} from "@/lib/supabase";
import { useAuth } from "@/components/auth-provider";
import { T } from "@/lib/theme";

/* ─── Pokeball Logo ─────────────────────────────────────────── */

function Pokeball() {
  return (
    <View
      style={{
        width: 64,
        height: 64,
        borderRadius: 18,
        borderCurve: "continuous",
        backgroundColor: T.accentLight,
        borderWidth: 1,
        borderColor: "rgba(211,47,47,0.2)",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <View
        style={{
          width: 36,
          height: 36,
          borderRadius: 18,
          borderWidth: 2.5,
          borderColor: T.accent,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <View
          style={{
            position: "absolute",
            width: 36,
            height: 2.5,
            backgroundColor: T.accent,
          }}
        />
        <View
          style={{
            width: 11,
            height: 11,
            borderRadius: 5.5,
            backgroundColor: T.accent,
            zIndex: 1,
          }}
        />
        <View
          style={{
            position: "absolute",
            width: 17,
            height: 17,
            borderRadius: 8.5,
            backgroundColor: T.bg,
            zIndex: 0,
          }}
        />
      </View>
    </View>
  );
}

/* ─── Input Field ───────────────────────────────────────────── */

function InputField({
  label,
  placeholder,
  value,
  onChangeText,
  secureTextEntry,
  keyboardType,
  textContentType,
  autoCapitalize,
  returnKeyType,
  onSubmitEditing,
  inputRef,
  error,
}: any) {
  const [focused, setFocused] = useState(false);
  const [hidden, setHidden] = useState(secureTextEntry ?? false);
  const borderAnim = useRef(new Animated.Value(0)).current;

  const onFocus = () => {
    setFocused(true);
    Animated.timing(borderAnim, {
      toValue: 1,
      duration: 180,
      useNativeDriver: false,
    }).start();
  };
  const onBlur = () => {
    setFocused(false);
    Animated.timing(borderAnim, {
      toValue: 0,
      duration: 180,
      useNativeDriver: false,
    }).start();
  };

  const borderColor = borderAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [T.border, T.borderFocus],
  });
  const bgColor = borderAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [T.surface, "#18181E"],
  });

  return (
    <View style={{ gap: 6 }}>
      <Text
        style={{
          fontSize: 13,
          fontWeight: "500",
          color: T.textSecondary,
          letterSpacing: 0.2,
        }}
      >
        {label}
      </Text>
      <Animated.View
        style={{
          borderRadius: 12,
          borderWidth: 1.5,
          borderColor: error ? T.accent : borderColor,
          backgroundColor: bgColor,
          flexDirection: "row",
          alignItems: "center",
          overflow: "hidden",
        }}
      >
        <TextInput
          ref={inputRef}
          placeholder={placeholder}
          placeholderTextColor={T.textTertiary}
          value={value}
          onChangeText={onChangeText}
          secureTextEntry={hidden}
          keyboardType={keyboardType}
          textContentType={textContentType}
          autoCapitalize={autoCapitalize ?? "none"}
          autoCorrect={false}
          returnKeyType={returnKeyType ?? "next"}
          onSubmitEditing={onSubmitEditing}
          onFocus={onFocus}
          onBlur={onBlur}
          style={{ flex: 1, padding: 14, fontSize: 15, color: T.text }}
        />
        {secureTextEntry && (
          <Pressable onPress={() => setHidden(!hidden)} style={{ padding: 14 }}>
            <Image
              source={hidden ? "sf:eye" : "sf:eye.slash"}
              style={{ width: 18, height: 18, tintColor: T.textTertiary }}
            />
          </Pressable>
        )}
      </Animated.View>
      {error && (
        <Text style={{ fontSize: 12, color: T.accent }}>{error}</Text>
      )}
    </View>
  );
}

/* ─── Validation ────────────────────────────────────────────── */

function validate(
  mode: "signin" | "signup",
  email: string,
  password: string,
  name: string
) {
  const errors: Record<string, string> = {};
  if (mode === "signup" && !name.trim()) errors.name = "Name is required.";
  if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    errors.email = "Enter a valid email address.";
  if (!password || password.length < 8)
    errors.password = "Password must be at least 8 characters.";
  return errors;
}

/* ─── Login Screen ──────────────────────────────────────────── */

export default function LoginScreen() {
  const router = useRouter();
  const { refreshAuth } = useAuth();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [oauthLoading, setOauthLoading] = useState<"google" | "apple" | null>(
    null
  );
  const [success, setSuccess] = useState(false);
  const [showForgot, setShowForgot] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotSent, setForgotSent] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);

  const emailRef = useRef<TextInput>(null);
  const passwordRef = useRef<TextInput>(null);
  const btnScale = useRef(new Animated.Value(1)).current;

  const pressBtnIn = () =>
    Animated.spring(btnScale, {
      toValue: 0.97,
      useNativeDriver: true,
      speed: 50,
    }).start();
  const pressBtnOut = () =>
    Animated.spring(btnScale, {
      toValue: 1,
      useNativeDriver: true,
      speed: 50,
    }).start();

  const switchMode = (m: "signin" | "signup") => {
    setMode(m);
    setErrors({});
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
  };

  const completeFlow = async () => {
    await AsyncStorage.setItem(AUTH_FLOW_KEY, "1");
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(
      () => {}
    );
    router.replace("/(tabs)");
  };

  /* ─── Email sign in/up ──────────────────────────────────── */

  const handleSubmit = async () => {
    const errs = validate(mode, email, password, name);
    if (Object.keys(errs).length) {
      setErrors(errs);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error).catch(
        () => {}
      );
      return;
    }
    if (mode === "signup" && !termsAccepted) {
      setErrors({ general: "Please accept the Terms & Privacy Policy." });
      return;
    }
    setErrors({});
    setLoading(true);
    try {
      if (mode === "signin") {
        await signInWithEmail(email.trim(), password);
        await refreshAuth();
        await completeFlow();
      } else {
        const user = await signUpWithEmail(email.trim(), password);
        if (
          user?.email_confirmed_at ||
          user?.confirmed_at ||
          user?.identities?.length
        ) {
          await refreshAuth();
          await completeFlow();
        } else {
          setSuccess(true);
        }
      }
    } catch (err: any) {
      const msg: string = err.message ?? "Something went wrong.";
      if (msg.toLowerCase().includes("password"))
        setErrors({ password: msg });
      else if (
        msg.toLowerCase().includes("email") ||
        msg.toLowerCase().includes("user")
      )
        setErrors({ email: msg });
      else setErrors({ general: msg });
    } finally {
      setLoading(false);
    }
  };

  /* ─── Google OAuth ──────────────────────────────────────── */

  const handleGoogle = async () => {
    setOauthLoading("google");
    try {
      await signInWithGoogle();
      await refreshAuth();
      await completeFlow();
    } catch (err: any) {
      if (!err.message?.includes("cancelled")) {
        Alert.alert("Google Sign-In", err.message ?? "Something went wrong.");
      }
    } finally {
      setOauthLoading(null);
    }
  };

  /* ─── Apple OAuth ───────────────────────────────────────── */

  const handleApple = async () => {
    setOauthLoading("apple");
    try {
      await signInWithApple();
      await refreshAuth();
      await completeFlow();
    } catch (err: any) {
      if (!err.message?.includes("cancelled")) {
        Alert.alert("Apple Sign-In", err.message ?? "Something went wrong.");
      }
    } finally {
      setOauthLoading(null);
    }
  };

  /* ─── Forgot password ──────────────────────────────────── */

  const handleForgotPassword = async () => {
    if (!forgotEmail.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(forgotEmail)) {
      Alert.alert("Invalid Email", "Please enter a valid email address.");
      return;
    }
    setLoading(true);
    try {
      await resetPassword(forgotEmail.trim());
      setForgotSent(true);
    } catch (err: any) {
      Alert.alert("Error", err.message ?? "Could not send reset email.");
    } finally {
      setLoading(false);
    }
  };

  /* ─── Forgot Password UI ───────────────────────────────── */

  if (showForgot) {
    return (
      <KeyboardAvoidingView
        style={{ flex: 1, backgroundColor: T.bg }}
        behavior="padding"
      >
        <ScrollView
          contentInsetAdjustmentBehavior="automatic"
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{
            flexGrow: 1,
            justifyContent: "center",
            paddingHorizontal: 28,
            gap: 20,
          }}
        >
          <View style={{ alignItems: "center", gap: 12 }}>
            <View
              style={{
                width: 64,
                height: 64,
                borderRadius: 32,
                backgroundColor: T.accentLight,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Image
                source="sf:lock.rotation"
                style={{ width: 30, height: 30, tintColor: T.accent }}
              />
            </View>
            <Text
              style={{
                fontSize: 24,
                fontWeight: "700",
                color: T.text,
                textAlign: "center",
              }}
            >
              Reset Password
            </Text>
            <Text
              style={{
                fontSize: 14,
                color: T.textSecondary,
                textAlign: "center",
                lineHeight: 20,
              }}
            >
              {forgotSent
                ? `We sent a password reset link to ${forgotEmail}. Check your email and follow the instructions.`
                : "Enter the email address associated with your account and we'll send you a reset link."}
            </Text>
          </View>

          {!forgotSent && (
            <>
              <InputField
                label="Email"
                placeholder="you@example.com"
                value={forgotEmail}
                onChangeText={setForgotEmail}
                keyboardType="email-address"
                textContentType="emailAddress"
                returnKeyType="done"
                onSubmitEditing={handleForgotPassword}
              />
              <Pressable
                onPress={handleForgotPassword}
                disabled={loading}
                style={{
                  paddingVertical: 15,
                  borderRadius: 14,
                  borderCurve: "continuous",
                  backgroundColor: T.accent,
                  alignItems: "center",
                  opacity: loading ? 0.7 : 1,
                }}
              >
                {loading ? (
                  <ActivityIndicator color="white" />
                ) : (
                  <Text
                    style={{
                      fontSize: 16,
                      fontWeight: "600",
                      color: "#fff",
                    }}
                  >
                    Send Reset Link
                  </Text>
                )}
              </Pressable>
            </>
          )}

          <Pressable
            onPress={() => {
              setShowForgot(false);
              setForgotSent(false);
              setForgotEmail("");
            }}
            style={{ alignSelf: "center", marginTop: 8 }}
          >
            <Text style={{ fontSize: 15, fontWeight: "600", color: T.accent }}>
              Back to Sign In
            </Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    );
  }

  /* ─── Email confirmation success ────────────────────────── */

  if (success) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: T.bg,
          justifyContent: "center",
          alignItems: "center",
          padding: 32,
          gap: 16,
        }}
      >
        <View
          style={{
            width: 80,
            height: 80,
            borderRadius: 40,
            backgroundColor: T.accentLight,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Image
            source="sf:envelope.badge.fill"
            style={{ width: 36, height: 36, tintColor: T.accent }}
          />
        </View>
        <Text
          style={{
            fontSize: 22,
            fontWeight: "700",
            color: T.text,
            textAlign: "center",
          }}
        >
          Check your email
        </Text>
        <Text
          style={{
            fontSize: 15,
            color: T.textSecondary,
            textAlign: "center",
            lineHeight: 22,
          }}
        >
          We sent a confirmation link to{"\n"}
          <Text style={{ color: T.text, fontWeight: "600" }}>{email}</Text>.
          {"\n"}Click it to activate your account.
        </Text>
        <Pressable
          onPress={() => {
            setSuccess(false);
            setMode("signin");
          }}
          style={{ marginTop: 8 }}
        >
          <Text style={{ fontSize: 16, fontWeight: "600", color: T.accent }}>
            Back to Sign In
          </Text>
        </Pressable>
      </View>
    );
  }

  /* ─── Main Login / Signup UI ────────────────────────────── */

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: T.bg }}
      behavior="padding"
    >
      <ScrollView
        contentInsetAdjustmentBehavior="automatic"
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{
          flexGrow: 1,
          paddingHorizontal: 28,
          paddingBottom: 40,
        }}
      >
        {/* Atmospheric glow */}
        <View
          pointerEvents="none"
          style={{
            position: "absolute",
            top: -60,
            left: "50%",
            marginLeft: -150,
            width: 300,
            height: 300,
            borderRadius: 150,
            backgroundColor: "rgba(211,47,47,0.06)",
          }}
        />

        {/* Logo area */}
        <View
          style={{
            alignItems: "center",
            paddingTop: 36,
            paddingBottom: 28,
            gap: 0,
          }}
        >
          <Pokeball />
          <View style={{ marginTop: 16, alignItems: "center", gap: 6 }}>
            <Text
              style={{
                fontSize: 28,
                fontWeight: "700",
                color: T.text,
                letterSpacing: -0.5,
              }}
            >
              Minty
            </Text>
            <Text
              style={{
                fontSize: 14,
                color: T.textTertiary,
                letterSpacing: 0.1,
              }}
            >
              Is your card mint? Find out instantly.
            </Text>
          </View>
        </View>

        {/* Tab switcher */}
        <View
          style={{
            flexDirection: "row",
            backgroundColor: T.surface,
            borderRadius: 12,
            borderCurve: "continuous",
            padding: 3,
            marginBottom: 24,
            borderWidth: 1,
            borderColor: T.border,
          }}
        >
          {(["signin", "signup"] as const).map((m) => (
            <Pressable
              key={m}
              onPress={() => switchMode(m)}
              style={{
                flex: 1,
                paddingVertical: 10,
                borderRadius: 10,
                alignItems: "center",
                backgroundColor:
                  mode === m ? T.surfaceHover : "transparent",
                ...(mode === m
                  ? { boxShadow: "0 2px 8px rgba(0,0,0,0.3)" }
                  : {}),
              }}
            >
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "600",
                  color: mode === m ? T.text : T.textTertiary,
                }}
              >
                {m === "signin" ? "Sign In" : "Create Account"}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Form */}
        <View style={{ gap: 16 }}>
          {mode === "signup" && (
            <InputField
              label="Full Name"
              placeholder="Your name"
              value={name}
              onChangeText={setName}
              autoCapitalize="words"
              returnKeyType="next"
              onSubmitEditing={() => emailRef.current?.focus()}
              error={errors.name}
            />
          )}
          <InputField
            label="Email"
            placeholder="you@example.com"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            textContentType="emailAddress"
            returnKeyType="next"
            onSubmitEditing={() => passwordRef.current?.focus()}
            inputRef={emailRef}
            error={errors.email}
          />
          <InputField
            label="Password"
            placeholder="••••••••"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            textContentType={
              mode === "signup" ? "newPassword" : "password"
            }
            returnKeyType="done"
            onSubmitEditing={handleSubmit}
            inputRef={passwordRef}
            error={errors.password}
          />

          {mode === "signin" && (
            <Pressable
              style={{ alignSelf: "flex-end", marginTop: -8 }}
              onPress={() => {
                setShowForgot(true);
                setForgotEmail(email);
              }}
            >
              <Text
                style={{
                  fontSize: 13,
                  fontWeight: "500",
                  color: T.accent,
                }}
              >
                Forgot password?
              </Text>
            </Pressable>
          )}

          {/* Terms checkbox for signup */}
          {mode === "signup" && (
            <Pressable
              onPress={() => setTermsAccepted(!termsAccepted)}
              style={{
                flexDirection: "row",
                alignItems: "flex-start",
                gap: 10,
                marginTop: 4,
              }}
            >
              <View
                style={{
                  width: 22,
                  height: 22,
                  borderRadius: 6,
                  borderWidth: 1.5,
                  borderColor: termsAccepted ? T.accent : T.border,
                  backgroundColor: termsAccepted
                    ? T.accent
                    : "transparent",
                  alignItems: "center",
                  justifyContent: "center",
                  marginTop: 1,
                }}
              >
                {termsAccepted && (
                  <Image
                    source="sf:checkmark"
                    style={{
                      width: 12,
                      height: 12,
                      tintColor: "#fff",
                    }}
                  />
                )}
              </View>
              <Text
                style={{
                  flex: 1,
                  fontSize: 13,
                  color: T.textSecondary,
                  lineHeight: 18,
                }}
              >
                I agree to the{" "}
                <Text
                  style={{ color: T.accent, fontWeight: "500" }}
                  onPress={() => router.push("/terms" as any)}
                >
                  Terms of Service
                </Text>{" "}
                and{" "}
                <Text
                  style={{ color: T.accent, fontWeight: "500" }}
                  onPress={() => router.push("/privacy" as any)}
                >
                  Privacy Policy
                </Text>
              </Text>
            </Pressable>
          )}
        </View>

        {errors.general && (
          <Text
            style={{
              fontSize: 13,
              color: T.accent,
              textAlign: "center",
              marginTop: 12,
            }}
          >
            {errors.general}
          </Text>
        )}

        {/* Primary CTA */}
        <Animated.View
          style={{ transform: [{ scale: btnScale }], marginTop: 24 }}
        >
          <Pressable
            onPressIn={pressBtnIn}
            onPressOut={pressBtnOut}
            onPress={handleSubmit}
            disabled={loading}
            style={{
              paddingVertical: 15,
              borderRadius: 14,
              borderCurve: "continuous",
              backgroundColor: T.accent,
              alignItems: "center",
              opacity: loading ? 0.7 : 1,
              boxShadow: "0 4px 24px rgba(211, 47, 47, 0.35)",
              experimental_backgroundImage: T.accentGradient,
            }}
          >
            {loading ? (
              <ActivityIndicator color="white" />
            ) : (
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "600",
                  color: "#fff",
                  letterSpacing: 0.3,
                }}
              >
                {mode === "signin" ? "Sign In" : "Create Account"}
              </Text>
            )}
          </Pressable>
        </Animated.View>

        {/* Divider */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 12,
            marginVertical: 20,
          }}
        >
          <View style={{ flex: 1, height: 1, backgroundColor: T.border }} />
          <Text
            style={{
              fontSize: 12,
              color: T.textTertiary,
              fontWeight: "500",
            }}
          >
            or continue with
          </Text>
          <View style={{ flex: 1, height: 1, backgroundColor: T.border }} />
        </View>

        {/* Social buttons */}
        <View style={{ flexDirection: "row", gap: 12 }}>
          <Pressable
            onPress={handleGoogle}
            disabled={!!oauthLoading}
            style={({ pressed }) => ({
              flex: 1,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              paddingVertical: 13,
              borderRadius: 12,
              borderWidth: 1.5,
              borderColor: T.border,
              backgroundColor: pressed ? T.surfaceHover : T.surface,
              opacity: oauthLoading === "apple" ? 0.5 : 1,
            })}
          >
            {oauthLoading === "google" ? (
              <ActivityIndicator size="small" color={T.text} />
            ) : (
              <>
                <View
                  style={{
                    width: 20,
                    height: 20,
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      fontWeight: "700",
                      color: "#4285F4",
                    }}
                  >
                    G
                  </Text>
                </View>
                <Text
                  style={{
                    color: T.text,
                    fontSize: 14,
                    fontWeight: "500",
                  }}
                >
                  Google
                </Text>
              </>
            )}
          </Pressable>
          <Pressable
            onPress={handleApple}
            disabled={!!oauthLoading}
            style={({ pressed }) => ({
              flex: 1,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              paddingVertical: 13,
              borderRadius: 12,
              borderWidth: 1.5,
              borderColor: T.border,
              backgroundColor: pressed ? T.surfaceHover : T.surface,
              opacity: oauthLoading === "google" ? 0.5 : 1,
            })}
          >
            {oauthLoading === "apple" ? (
              <ActivityIndicator size="small" color={T.text} />
            ) : (
              <>
                <Image
                  source="sf:apple.logo"
                  style={{ width: 18, height: 18, tintColor: T.text }}
                />
                <Text
                  style={{
                    color: T.text,
                    fontSize: 14,
                    fontWeight: "500",
                  }}
                >
                  Apple
                </Text>
              </>
            )}
          </Pressable>
        </View>

        {/* Footer */}
        <View style={{ alignItems: "center", gap: 8, marginTop: 28 }}>
          <View
            style={{
              flexDirection: "row",
              gap: 4,
              alignItems: "center",
            }}
          >
            <Text style={{ fontSize: 14, color: T.textSecondary }}>
              {mode === "signin"
                ? "Don't have an account?"
                : "Already have an account?"}
            </Text>
            <Pressable
              onPress={() =>
                switchMode(mode === "signin" ? "signup" : "signin")
              }
            >
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "600",
                  color: T.accent,
                }}
              >
                {mode === "signin" ? "Sign up" : "Sign in"}
              </Text>
            </Pressable>
          </View>
          <Pressable onPress={() => completeFlow()}>
            <Text style={{ fontSize: 13, color: T.textTertiary }}>
              Continue as Guest
            </Text>
          </Pressable>
          <Text
            style={{
              fontSize: 11,
              color: T.textTertiary,
              textAlign: "center",
              marginTop: 4,
              lineHeight: 16,
            }}
          >
            By continuing, you agree to our{" "}
            <Text
              style={{ color: T.textSecondary }}
              onPress={() => router.push("/terms" as any)}
            >
              Terms
            </Text>{" "}
            and{" "}
            <Text
              style={{ color: T.textSecondary }}
              onPress={() => router.push("/privacy" as any)}
            >
              Privacy Policy
            </Text>
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
