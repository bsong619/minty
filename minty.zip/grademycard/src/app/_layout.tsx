import { useEffect } from "react";
import Stack from "expo-router/stack";
import { useRouter, useSegments } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { StatusBar } from "expo-status-bar";
import { View } from "react-native";
import { ThemeProvider } from "@/components/theme-provider";
import AuthProvider from "@/components/auth-provider";
import { useAuth } from "@/components/auth-provider";
import { initializeIAP, terminateIAP } from "@/lib/iap-service";
import { T } from "@/lib/theme";

export const AUTH_FLOW_KEY = "auth_flow_seen";

function AuthGate() {
  const { loading, userId } = useAuth();
  const router = useRouter();
  const segments = useSegments();

  useEffect(() => {
    if (loading) return;

    AsyncStorage.getItem(AUTH_FLOW_KEY).then((val) => {
      const inLogin = segments[0] === "login";
      const inTerms = segments[0] === "terms";
      const inPrivacy = segments[0] === "privacy";
      if (!val && !inLogin && !inTerms && !inPrivacy) {
        router.replace("/login");
      }
    });
  }, [loading, userId]);

  return null;
}

function IAPInitializer() {
  useEffect(() => {
    initializeIAP().catch(() => {});
    return () => {
      terminateIAP().catch(() => {});
    };
  }, []);
  return null;
}

export default function Layout() {
  return (
    <View style={{ flex: 1, backgroundColor: T.bg }}>
      <StatusBar style="light" />
      <ThemeProvider>
        <AuthProvider>
          <IAPInitializer />
          <AuthGate />
          <Stack
            screenOptions={{
              headerShown: false,
              contentStyle: { backgroundColor: T.bg },
              animation: "fade_from_bottom",
              animationDuration: 250,
            }}
          >
            <Stack.Screen
              name="login"
              options={{
                animation: "fade",
                animationDuration: 300,
              }}
            />
            <Stack.Screen
              name="(tabs)"
              options={{
                animation: "fade",
                animationDuration: 300,
              }}
            />
            <Stack.Screen
              name="onboarding"
              options={{
                animation: "slide_from_right",
                animationDuration: 300,
              }}
            />
            <Stack.Screen
              name="paywall"
              options={{
                presentation: "modal",
                headerShown: false,
                animation: "slide_from_bottom",
                animationDuration: 350,
              }}
            />
            <Stack.Screen
              name="terms"
              options={{
                presentation: "modal",
                headerShown: false,
                animation: "slide_from_bottom",
                animationDuration: 300,
              }}
            />
            <Stack.Screen
              name="privacy"
              options={{
                presentation: "modal",
                headerShown: false,
                animation: "slide_from_bottom",
                animationDuration: 300,
              }}
            />
          </Stack>
        </AuthProvider>
      </ThemeProvider>
    </View>
  );
}
