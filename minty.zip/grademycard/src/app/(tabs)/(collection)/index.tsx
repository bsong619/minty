import { useCallback, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  RefreshControl,
  useWindowDimensions,
} from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import { Image } from "expo-image";
import CollectionCard from "@/components/collection-card";
import { getCards } from "@/lib/storage";
import { getScannedCards } from "@/lib/card-service";
import { useAuth } from "@/components/auth-provider";
import { GradedCard } from "@/lib/types";
import { T } from "@/lib/theme";

const COLUMNS = 2;
const PADDING = 16;
const GAP = 12;

export default function CollectionScreen() {
  const router = useRouter();
  const { userId } = useAuth();
  const { width: screenWidth } = useWindowDimensions();
  const cardWidth =
    (screenWidth - PADDING * 2 - GAP * (COLUMNS - 1)) / COLUMNS;
  const [cards, setCards] = useState<GradedCard[]>([]);
  const [filter, setFilter] = useState<"all" | "favorites">("all");
  const [refreshing, setRefreshing] = useState(false);

  const loadCards = useCallback(async () => {
    if (userId) {
      const data = await getScannedCards(userId);
      setCards(data);
    } else {
      const data = await getCards();
      setCards(data);
    }
  }, [userId]);

  useFocusEffect(
    useCallback(() => {
      loadCards();
    }, [loadCards])
  );

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadCards();
    setRefreshing(false);
  }, [loadCards]);

  const filteredCards =
    filter === "favorites" ? cards.filter((c) => c.favorite) : cards;

  return (
    <ScrollView
      contentInsetAdjustmentBehavior="automatic"
      style={{ flex: 1, backgroundColor: T.bg }}
      contentContainerStyle={{
        padding: 16,
        gap: 16,
        paddingBottom: 40,
      }}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onRefresh}
          tintColor={T.accent}
        />
      }
    >
      {/* Filter Pills */}
      <View style={{ flexDirection: "row", gap: 8 }}>
        {(["all", "favorites"] as const).map((f) => (
          <Pressable
            key={f}
            onPress={() => setFilter(f)}
            style={{
              paddingHorizontal: 16,
              paddingVertical: 8,
              borderRadius: 20,
              backgroundColor: filter === f ? T.accent : T.surface,
              borderWidth: 1,
              borderColor: filter === f ? T.accent : T.borderSubtle,
            }}
          >
            <Text
              style={{
                fontSize: 14,
                fontWeight: "600",
                color: filter === f ? "#fff" : T.text,
                textTransform: "capitalize",
              }}
            >
              {f === "all" ? `All (${cards.length})` : "Favorites"}
            </Text>
          </Pressable>
        ))}
      </View>

      {filteredCards.length === 0 ? (
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            paddingTop: 80,
            gap: 16,
          }}
        >
          <View
            style={{
              width: 72,
              height: 72,
              borderRadius: 36,
              backgroundColor: T.accentLight,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Image
              source="sf:rectangle.stack"
              style={{
                width: 32,
                height: 32,
                tintColor: T.textTertiary,
              }}
            />
          </View>
          <Text
            style={{
              fontSize: 17,
              fontWeight: "600",
              color: T.textSecondary,
              textAlign: "center",
            }}
          >
            {filter === "favorites"
              ? "No Favorites Yet"
              : "No Cards Scanned Yet"}
          </Text>
          <Text
            style={{
              fontSize: 14,
              color: T.textTertiary,
              textAlign: "center",
              lineHeight: 20,
            }}
          >
            {filter === "favorites"
              ? "Tap the heart on a graded card to save it here."
              : "Scan your first card from the Scan tab!"}
          </Text>
        </View>
      ) : (
        <View
          style={{
            flexDirection: "row",
            flexWrap: "wrap",
            gap: GAP,
          }}
        >
          {filteredCards.map((card) => (
            <CollectionCard
              key={card.id}
              card={card}
              width={cardWidth}
              onPress={() =>
                router.push({
                  pathname: "/(tabs)/(collection)/details",
                  params: { cardId: card.id },
                })
              }
            />
          ))}
        </View>
      )}
    </ScrollView>
  );
}
