import Stack from "expo-router/stack";
import { T } from "@/lib/theme";

export default function SettingsLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: true,
        headerStyle: { backgroundColor: T.bg },
        headerTintColor: T.text,
        headerTitleStyle: { color: T.text, fontWeight: "700" },
        headerShadowVisible: false,
        contentStyle: { backgroundColor: T.bg },
        animation: "slide_from_right",
        animationDuration: 250,
      }}
    >
      <Stack.Screen
        name="index"
        options={{
          title: "Settings",
          headerLargeTitle: true,
          headerLargeStyle: { backgroundColor: T.bg },
        }}
      />
    </Stack>
  );
}
