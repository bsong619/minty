import {
  View,
  Text,
  ScrollView,
  Pressable,
  Alert,
} from "react-native";
import { useRouter } from "expo-router";
import { Image } from "expo-image";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAuth } from "@/components/auth-provider";
import { useSubscription } from "@/hooks/use-subscription";
import { T } from "@/lib/theme";

function SettingsRow({
  icon,
  label,
  value,
  onPress,
  destructive,
}: {
  icon: string;
  label: string;
  value?: string;
  onPress?: () => void;
  destructive?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={({ pressed }) => ({
        flexDirection: "row",
        alignItems: "center",
        gap: 12,
        padding: 14,
        opacity: pressed && onPress ? 0.7 : 1,
        backgroundColor: pressed && onPress ? T.surfaceHover : "transparent",
      })}
    >
      <View
        style={{
          width: 32,
          height: 32,
          borderRadius: 8,
          backgroundColor: destructive
            ? "rgba(255,59,48,0.1)"
            : T.accentLight,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Image
          source={`sf:${icon}`}
          style={{
            width: 16,
            height: 16,
            tintColor: destructive ? T.danger : T.accent,
          }}
        />
      </View>
      <Text
        style={{
          fontSize: 16,
          color: destructive ? T.danger : T.text,
          flex: 1,
        }}
      >
        {label}
      </Text>
      {value && (
        <Text
          style={{ fontSize: 14, color: T.textSecondary }}
          numberOfLines={1}
        >
          {value}
        </Text>
      )}
      {onPress && !destructive && (
        <Image
          source="sf:chevron.right"
          style={{
            width: 12,
            height: 12,
            tintColor: T.textTertiary,
          }}
        />
      )}
    </Pressable>
  );
}

function SettingsSection({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <View style={{ gap: 2 }}>
      <Text
        style={{
          fontSize: 13,
          fontWeight: "600",
          color: T.textSecondary,
          textTransform: "uppercase",
          letterSpacing: 0.5,
          marginBottom: 6,
          marginLeft: 4,
        }}
      >
        {title}
      </Text>
      <View
        style={{
          borderRadius: 14,
          borderCurve: "continuous",
          backgroundColor: T.surface,
          overflow: "hidden",
          borderWidth: 1,
          borderColor: T.borderSubtle,
        }}
      >
        {children}
      </View>
    </View>
  );
}

function Divider() {
  return (
    <View
      style={{
        height: 0.5,
        backgroundColor: T.border,
        marginLeft: 58,
      }}
    />
  );
}

export default function SettingsScreen() {
  const router = useRouter();
  const { userEmail, isAnonymous, signOut } = useAuth();
  const { isPro, restore } = useSubscription();

  const handleSignOut = () => {
    Alert.alert("Sign Out", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Sign Out",
        style: "destructive",
        onPress: async () => {
          await signOut();
          router.replace("/login");
        },
      },
    ]);
  };

  const handleClearData = () => {
    Alert.alert(
      "Clear All Data",
      "This will permanently delete all your scanned cards and history. This cannot be undone.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Clear All Data",
          style: "destructive",
          onPress: async () => {
            await AsyncStorage.clear();
            Alert.alert("Done", "All data has been cleared.");
          },
        },
      ]
    );
  };

  const handleResetOnboarding = () => {
    AsyncStorage.removeItem("minty_onboarding_seen").then(() => {
      router.push("/onboarding" as any);
    });
  };

  const handleRestorePurchases = async () => {
    const result = await restore();
    if (result.status === "success") {
      Alert.alert("Restored!", "Your Pro subscription has been restored.");
    } else {
      Alert.alert(
        "No Purchase Found",
        result.message ?? "No active subscription was found."
      );
    }
  };

  return (
    <ScrollView
      contentInsetAdjustmentBehavior="automatic"
      style={{ flex: 1, backgroundColor: T.bg }}
      contentContainerStyle={{
        padding: 16,
        gap: 24,
        paddingBottom: 40,
      }}
    >
      {/* Pro Banner */}
      {isPro ? (
        <View
          style={{
            borderRadius: 16,
            borderCurve: "continuous",
            padding: 20,
            backgroundColor: T.surface,
            gap: 8,
            borderWidth: 1,
            borderColor: "rgba(211,47,47,0.3)",
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <View
            style={{
              width: 44,
              height: 44,
              borderRadius: 12,
              backgroundColor: T.accentLight,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Image
              source="sf:crown.fill"
              style={{ width: 22, height: 22, tintColor: T.accent }}
            />
          </View>
          <View style={{ flex: 1, marginLeft: 4 }}>
            <Text style={{ fontSize: 17, fontWeight: "700", color: T.text }}>
              Minty Pro
            </Text>
            <Text
              style={{
                fontSize: 13,
                color: T.textSecondary,
                marginTop: 2,
              }}
            >
              Unlimited scans active
            </Text>
          </View>
          <Image
            source="sf:checkmark.seal.fill"
            style={{ width: 22, height: 22, tintColor: T.success }}
          />
        </View>
      ) : (
        <Pressable
          onPress={() => router.push("/paywall" as any)}
          style={({ pressed }) => ({
            borderRadius: 16,
            borderCurve: "continuous",
            padding: 20,
            backgroundColor: T.accent,
            gap: 8,
            boxShadow: "0px 4px 20px rgba(211,47,47,0.4)",
            opacity: pressed ? 0.9 : 1,
            experimental_backgroundImage: T.accentGradient,
          })}
        >
          <Text style={{ fontSize: 20, fontWeight: "800", color: "#fff" }}>
            Upgrade to Pro
          </Text>
          <Text
            style={{
              fontSize: 14,
              color: "rgba(255,255,255,0.85)",
              lineHeight: 20,
            }}
          >
            Unlimited scans, market value estimates, batch scanning, and
            priority processing.
          </Text>
          <Text
            style={{
              fontSize: 16,
              fontWeight: "700",
              color: "#fff",
              marginTop: 4,
            }}
          >
            $4.99/month or $29.99/year →
          </Text>
        </Pressable>
      )}

      {/* Account */}
      <SettingsSection title="Account">
        {isAnonymous ? (
          <>
            <SettingsRow
              icon="person.crop.circle.badge.plus"
              label="Sign In / Create Account"
              onPress={() => router.push("/login" as any)}
            />
            <Divider />
            <SettingsRow
              icon="rectangle.portrait.and.arrow.right"
              label="Sign Out"
              onPress={handleSignOut}
              destructive
            />
          </>
        ) : (
          <>
            <SettingsRow
              icon="person.crop.circle"
              label="Signed in as"
              value={userEmail ?? ""}
            />
            <Divider />
            <SettingsRow
              icon="rectangle.portrait.and.arrow.right"
              label="Sign Out"
              onPress={handleSignOut}
              destructive
            />
          </>
        )}
      </SettingsSection>

      {/* Subscription */}
      <SettingsSection title="Subscription">
        {isPro ? (
          <SettingsRow
            icon="crown.fill"
            label="Manage Subscription"
            onPress={() => router.push("/paywall" as any)}
          />
        ) : (
          <SettingsRow
            icon="crown"
            label="Upgrade to Pro"
            onPress={() => router.push("/paywall" as any)}
          />
        )}
        <Divider />
        <SettingsRow
          icon="arrow.clockwise"
          label="Restore Purchases"
          onPress={handleRestorePurchases}
        />
      </SettingsSection>

      {/* General */}
      <SettingsSection title="General">
        <SettingsRow
          icon="questionmark.circle"
          label="How to Photograph Cards"
          onPress={handleResetOnboarding}
        />
        <Divider />
        <SettingsRow icon="info.circle" label="App Version" value="1.0.0" />
      </SettingsSection>

      {/* About */}
      <SettingsSection title="About">
        <SettingsRow
          icon="hand.raised"
          label="Privacy Policy"
          onPress={() => router.push("/privacy" as any)}
        />
        <Divider />
        <SettingsRow
          icon="doc.text"
          label="Terms of Service"
          onPress={() => router.push("/terms" as any)}
        />
      </SettingsSection>

      {/* Data */}
      <SettingsSection title="Data">
        <SettingsRow
          icon="trash"
          label="Clear All Data"
          onPress={handleClearData}
          destructive
        />
      </SettingsSection>

      <Text
        style={{
          fontSize: 12,
          color: T.textTertiary,
          textAlign: "center",
          marginTop: 8,
          lineHeight: 18,
        }}
      >
        Minty is not affiliated with PSA (Professional Sports
        Authenticator). Grade predictions are estimates only.
      </Text>
    </ScrollView>
  );
}
