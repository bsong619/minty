import { useEffect, useState } from "react";
import { View, Text, ScrollView, Pressable } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Image } from "expo-image";
import * as Haptics from "expo-haptics";
import GradeBadge from "@/components/grade-badge";
import SubGradeBar from "@/components/sub-grade-bar";
import { getGradeColor, getConfidenceColor } from "@/lib/grade-colors";
import {
  getCards,
  toggleFavorite as localToggleFavorite,
} from "@/lib/storage";
import {
  getScannedCardById,
  toggleFavorite as sbToggleFavorite,
} from "@/lib/card-service";
import { useAuth } from "@/components/auth-provider";
import { GradedCard } from "@/lib/types";
import { T } from "@/lib/theme";

export default function ResultsScreen() {
  const { cardId } = useLocalSearchParams<{ cardId: string }>();
  const router = useRouter();
  const { userId } = useAuth();
  const [card, setCard] = useState<GradedCard | null>(null);

  useEffect(() => {
    if (userId) {
      getScannedCardById(cardId).then((c) => {
        if (c) setCard(c);
      });
    } else {
      getCards().then((cards) => {
        const found = cards.find((c) => c.id === cardId);
        if (found) setCard(found);
      });
    }
  }, [cardId, userId]);

  if (!card) {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
          backgroundColor: T.bg,
        }}
      >
        <Text style={{ color: T.textSecondary }}>Loading...</Text>
      </View>
    );
  }

  const { result } = card;
  const gradeColor = getGradeColor(result.overallGrade);
  const confidenceColor = getConfidenceColor(result.confidence);
  const gradeLabel =
    result.overallGrade === 10
      ? "Gem Mint"
      : result.overallGrade === 9
        ? "Mint"
        : result.overallGrade >= 7
          ? "Near Mint"
          : result.overallGrade >= 5
            ? "Excellent"
            : "Poor-VG";

  return (
    <ScrollView
      contentInsetAdjustmentBehavior="automatic"
      style={{ flex: 1, backgroundColor: T.bg }}
      contentContainerStyle={{ padding: 20, gap: 20, paddingBottom: 40 }}
    >
      {/* Card Image + Grade */}
      <View style={{ alignItems: "center", gap: 16 }}>
        <View
          style={{
            boxShadow: "0px 8px 24px rgba(0,0,0,0.5)",
            borderRadius: 12,
            borderCurve: "continuous",
          }}
        >
          <Image
            source={{ uri: card.imageUri }}
            style={{
              width: 220,
              height: 308,
              borderRadius: 12,
              borderCurve: "continuous",
            }}
            contentFit="cover"
          />
        </View>
        <GradeBadge grade={result.overallGrade} size="large" />
        <View style={{ alignItems: "center", gap: 4 }}>
          <Text
            style={{ fontSize: 24, fontWeight: "800", color: gradeColor }}
          >
            PSA {result.overallGrade} — {gradeLabel}
          </Text>
          <View
            style={{ flexDirection: "row", alignItems: "center", gap: 6 }}
          >
            <View
              style={{
                width: 8,
                height: 8,
                borderRadius: 4,
                backgroundColor: confidenceColor,
              }}
            />
            <Text
              style={{
                fontSize: 14,
                color: confidenceColor,
                fontWeight: "600",
              }}
            >
              {result.confidence} Confidence
            </Text>
          </View>
        </View>
      </View>

      {/* Card ID */}
      <CardSection title="Card Identified">
        <Text
          selectable
          style={{ fontSize: 20, fontWeight: "700", color: T.text }}
        >
          {result.cardName}
        </Text>
        <Text selectable style={{ fontSize: 15, color: T.textSecondary }}>
          {result.cardSet} ({result.cardYear}) · #{result.cardNumber}
        </Text>
      </CardSection>

      {/* Sub-Grades */}
      <CardSection title="Sub-Grade Breakdown">
        <SubGradeBar
          label="Centering"
          score={result.subGrades.centering}
          detail={`${result.centeringDetail.leftRight} LR · ${result.centeringDetail.topBottom} TB`}
        />
        <SubGradeBar label="Corners" score={result.subGrades.corners} />
        <SubGradeBar label="Edges" score={result.subGrades.edges} />
        <SubGradeBar label="Surface" score={result.subGrades.surface} />
      </CardSection>

      {/* Tips */}
      {result.tips.length > 0 && (
        <CardSection title="Grade-Up Tips">
          {result.tips.map((tip, i) => (
            <View key={i} style={{ flexDirection: "row", gap: 10 }}>
              <View
                style={{
                  width: 6,
                  height: 6,
                  borderRadius: 3,
                  backgroundColor: T.accent,
                  marginTop: 7,
                }}
              />
              <Text
                selectable
                style={{
                  fontSize: 14,
                  color: T.text,
                  lineHeight: 20,
                  flex: 1,
                }}
              >
                {tip}
              </Text>
            </View>
          ))}
        </CardSection>
      )}

      {/* Action Buttons */}
      <View style={{ flexDirection: "row", gap: 12 }}>
        <Pressable
          onPress={async () => {
            if (card) {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(
                () => {}
              );
              const newVal = !card.favorite;
              if (userId) {
                await sbToggleFavorite(card.id, newVal);
              } else {
                await localToggleFavorite(card.id);
              }
              setCard({ ...card, favorite: newVal });
            }
          }}
          style={({ pressed }) => ({
            flex: 1,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            padding: 14,
            borderRadius: 14,
            borderCurve: "continuous",
            backgroundColor: card.favorite
              ? "rgba(255,59,48,0.12)"
              : T.surface,
            borderWidth: 1,
            borderColor: card.favorite ? "rgba(255,59,48,0.3)" : T.borderSubtle,
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Image
            source={card.favorite ? "sf:heart.fill" : "sf:heart"}
            style={{
              width: 18,
              height: 18,
              tintColor: card.favorite ? T.danger : T.textSecondary,
            }}
          />
          <Text
            style={{
              fontSize: 15,
              fontWeight: "600",
              color: card.favorite ? T.danger : T.text,
            }}
          >
            {card.favorite ? "Saved" : "Save"}
          </Text>
        </Pressable>
        <Pressable
          onPress={() => router.dismissTo("/(scan)")}
          style={({ pressed }) => ({
            flex: 1,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            padding: 14,
            borderRadius: 14,
            borderCurve: "continuous",
            backgroundColor: T.accent,
            opacity: pressed ? 0.85 : 1,
          })}
        >
          <Image
            source="sf:viewfinder"
            style={{ width: 18, height: 18, tintColor: "white" }}
          />
          <Text style={{ fontSize: 15, fontWeight: "600", color: "white" }}>
            Scan Another
          </Text>
        </Pressable>
      </View>

      <Text
        selectable
        style={{
          fontSize: 11,
          color: T.textTertiary,
          textAlign: "center",
          lineHeight: 16,
        }}
      >
        This is an estimate, not a guarantee. Actual PSA grades may differ due
        to human subjectivity in the grading process.
      </Text>
    </ScrollView>
  );
}

function CardSection({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <View
      style={{
        borderRadius: 16,
        borderCurve: "continuous",
        backgroundColor: T.surface,
        padding: 16,
        gap: 10,
        borderWidth: 1,
        borderColor: T.borderSubtle,
      }}
    >
      <Text
        style={{
          fontSize: 13,
          fontWeight: "600",
          color: T.textSecondary,
          textTransform: "uppercase",
          letterSpacing: 0.5,
        }}
      >
        {title}
      </Text>
      {children}
    </View>
  );
}
