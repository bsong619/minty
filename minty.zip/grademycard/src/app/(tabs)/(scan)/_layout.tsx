import Stack from "expo-router/stack";
import { T } from "@/lib/theme";

export default function ScanLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: true,
        headerStyle: { backgroundColor: T.bg },
        headerTintColor: T.text,
        headerTitleStyle: { color: T.text, fontWeight: "700" },
        headerShadowVisible: false,
        contentStyle: { backgroundColor: T.bg },
        animation: "fade_from_bottom",
        animationDuration: 250,
      }}
    >
      <Stack.Screen
        name="index"
        options={{
          title: "Minty",
          headerLargeTitle: true,
          headerLargeStyle: { backgroundColor: T.bg },
        }}
      />
      <Stack.Screen
        name="analyzing"
        options={{
          title: "Analyzing",
          presentation: "modal",
          headerShown: false,
          animation: "fade",
        }}
      />
      <Stack.Screen
        name="results"
        options={{
          title: "Grade Results",
          animation: "slide_from_right",
        }}
      />
    </Stack>
  );
}
