import { useEffect, useState, useCallback } from "react";
import { View, Text, ScrollView, Alert, Pressable } from "react-native";
import { useRouter } from "expo-router";
import * as ImagePicker from "expo-image-picker";
import * as Haptics from "expo-haptics";
import { Asset } from "expo-asset";
import { Image } from "expo-image";
import ScanButton from "@/components/scan-button";
import { getDailyScans } from "@/lib/storage";
import { hasSeenOnboarding } from "@/lib/storage";
import { checkScanLimit } from "@/lib/card-service";
import { useAuth } from "@/components/auth-provider";
import { useSubscription } from "@/hooks/use-subscription";
import { setPendingImageUri } from "@/lib/pending-scan";
import { T } from "@/lib/theme";

const FREE_DAILY_LIMIT = 3;

export default function ScanScreen() {
  const router = useRouter();
  const { userId } = useAuth();
  const { isPro, scansRemaining: proScansRemaining } = useSubscription();
  const [scansToday, setScansToday] = useState(0);
  const [scansRemaining, setScansRemaining] = useState(FREE_DAILY_LIMIT);

  useEffect(() => {
    if (isPro) {
      setScansRemaining(Infinity);
      return;
    }
    if (userId) {
      checkScanLimit(userId).then((result) => {
        setScansRemaining(
          result.scansRemaining === Infinity
            ? FREE_DAILY_LIMIT
            : result.scansRemaining
        );
        setScansToday(
          FREE_DAILY_LIMIT -
            (result.scansRemaining === Infinity ? 0 : result.scansRemaining)
        );
      });
    } else {
      getDailyScans().then(setScansToday);
    }
  }, [userId, isPro]);

  useEffect(() => {
    hasSeenOnboarding().then((seen) => {
      if (!seen) {
        router.push("/onboarding" as any);
      }
    });
  }, []);

  const handleImageSelected = useCallback(
    (uri: string) => {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
      setPendingImageUri(uri);
      router.push("/(tabs)/(scan)/analyzing");
    },
    [router]
  );

  const checkLimitAndProceed = useCallback(
    async (launcher: () => Promise<string | null>) => {
      try {
        const uri = await launcher();
        if (!uri) return;
        handleImageSelected(uri);
      } catch (err: any) {
        console.error("Scan error:", err);
      }
    },
    [handleImageSelected]
  );

  const takePhoto = useCallback(async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== "granted") {
      Alert.alert(
        "Camera Permission",
        "Camera access is needed to photograph your cards."
      );
      return null;
    }
    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ["images"],
      quality: 0.9,
      allowsEditing: true,
      aspect: [63, 88],
    });
    if (result.canceled) return null;
    return result.assets[0].uri;
  }, []);

  const pickImage = useCallback(async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      quality: 0.9,
    });
    if (result.canceled) return null;
    return result.assets[0].uri;
  }, []);

  const testScan = useCallback(async () => {
    const [asset] = await Asset.loadAsync(require("@/assets/test-card.png"));
    handleImageSelected(asset.localUri ?? asset.uri);
  }, [handleImageSelected]);

  const remaining = isPro
    ? Infinity
    : userId
      ? scansRemaining
      : Math.max(0, FREE_DAILY_LIMIT - scansToday);

  return (
    <ScrollView
      contentInsetAdjustmentBehavior="automatic"
      style={{ flex: 1, backgroundColor: T.bg }}
      contentContainerStyle={{ padding: 20, gap: 24, paddingBottom: 40 }}
    >
      {/* Hero card */}
      <View
        style={{
          borderRadius: 20,
          borderCurve: "continuous",
          padding: 28,
          alignItems: "center",
          gap: 14,
          backgroundColor: T.surface,
          borderWidth: 1,
          borderColor: T.borderSubtle,
          boxShadow: "0px 4px 20px rgba(0,0,0,0.4)",
        }}
      >
        {/* Glow behind icon */}
        <View
          style={{
            width: 80,
            height: 80,
            borderRadius: 40,
            backgroundColor: T.accentLight,
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          {process.env.EXPO_OS === "web" ? (
            <Text style={{ fontSize: 40 }}>🃏</Text>
          ) : (
            <Image
              source="sf:viewfinder"
              style={{ width: 36, height: 36, tintColor: T.accent }}
            />
          )}
        </View>
        <Text
          style={{
            fontSize: 22,
            fontWeight: "700",
            color: T.text,
            textAlign: "center",
          }}
        >
          Grade Your Card
        </Text>
        <Text
          style={{
            fontSize: 15,
            color: T.textSecondary,
            textAlign: "center",
            lineHeight: 22,
          }}
        >
          Take or upload a photo of your Pokemon card to get an instant AI
          grade prediction.
        </Text>
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 6,
            marginTop: 4,
            paddingHorizontal: 12,
            paddingVertical: 6,
            borderRadius: 20,
            backgroundColor: remaining > 0 ? "rgba(52,199,89,0.1)" : "rgba(255,59,48,0.1)",
          }}
        >
          <View
            style={{
              width: 8,
              height: 8,
              borderRadius: 4,
              backgroundColor: remaining > 0 ? T.success : T.danger,
            }}
          />
          <Text
            style={{
              fontSize: 13,
              color: remaining > 0 ? T.success : T.danger,
              fontWeight: "600",
              fontVariant: ["tabular-nums"],
            }}
          >
            {remaining === Infinity
              ? "Unlimited scans — Pro"
              : `${remaining} free scan${remaining !== 1 ? "s" : ""} remaining today`}
          </Text>
        </View>
      </View>

      {/* Action buttons */}
      <View style={{ gap: 12 }}>
        <ScanButton
          icon="camera.fill"
          label="Take Photo"
          subtitle="Use your camera to photograph a card"
          onPress={() => checkLimitAndProceed(takePhoto)}
        />
        <ScanButton
          icon="photo.on.rectangle"
          label="Upload Photo"
          subtitle="Select an image from your photo library"
          onPress={() => checkLimitAndProceed(pickImage)}
        />
        {__DEV__ && (
          <ScanButton
            icon="checkmark.seal.fill"
            label="Test Scan"
            subtitle="Grade a sample 1st Ed. Charizard"
            onPress={testScan}
          />
        )}
      </View>

      {/* Tips */}
      <View style={{ gap: 12 }}>
        <Text
          style={{
            fontSize: 13,
            fontWeight: "600",
            color: T.textSecondary,
            textTransform: "uppercase",
            letterSpacing: 0.5,
          }}
        >
          Tips for Best Results
        </Text>
        {[
          "Place card on a dark, flat surface",
          "Use even lighting — avoid glare and shadows",
          "Fill the frame with the card",
          "Keep the camera steady and in focus",
        ].map((tip, i) => (
          <View
            key={i}
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 10,
              paddingVertical: 8,
              paddingHorizontal: 12,
              borderRadius: 10,
              backgroundColor: T.surface,
            }}
          >
            <View
              style={{
                width: 24,
                height: 24,
                borderRadius: 12,
                backgroundColor: T.accentLight,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "700",
                  color: T.accent,
                }}
              >
                {i + 1}
              </Text>
            </View>
            <Text style={{ fontSize: 14, color: T.textSecondary, flex: 1 }}>
              {tip}
            </Text>
          </View>
        ))}
      </View>

      <Text
        selectable
        style={{
          fontSize: 11,
          color: T.textTertiary,
          textAlign: "center",
          marginTop: 8,
          lineHeight: 16,
        }}
      >
        Minty provides estimates only. Predicted grades are not
        guaranteed and may differ from official PSA results.
      </Text>
    </ScrollView>
  );
}
