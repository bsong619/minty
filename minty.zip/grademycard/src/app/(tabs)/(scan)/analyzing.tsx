import { useEffect, useRef, useState } from "react";
import { View, Text, Animated, Easing, Alert } from "react-native";
import { useRouter } from "expo-router";
import { Image } from "expo-image";
import { analyzeCard } from "@/lib/grading-engine";
import { saveCompleteScan, checkScanLimit } from "@/lib/card-service";
import { useAuth } from "@/components/auth-provider";
import { saveCard, incrementDailyScans } from "@/lib/storage";
import { consumePendingImageUri } from "@/lib/pending-scan";
import { GradedCard } from "@/lib/types";
import { T } from "@/lib/theme";

export default function AnalyzingScreen() {
  const [imageUri] = useState(() => consumePendingImageUri() ?? "");
  const router = useRouter();
  const { userId } = useAuth();
  const pulseAnim = useRef(new Animated.Value(0.4)).current;
  const rotateAnim = useRef(new Animated.Value(0)).current;
  const dotAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 800,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: false,
        }),
        Animated.timing(pulseAnim, {
          toValue: 0.4,
          duration: 800,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: false,
        }),
      ])
    ).start();

    Animated.loop(
      Animated.timing(rotateAnim, {
        toValue: 1,
        duration: 1500,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    ).start();
  }, []);

  useEffect(() => {
    if (!imageUri) return;

    (async () => {
      try {
        if (userId) {
          const limit = await checkScanLimit(userId);
          if (!limit.canScan) {
            Alert.alert(
              "Daily Limit Reached",
              "You've used all 3 free scans today. Upgrade to Pro for unlimited scans!",
              [{ text: "OK" }]
            );
            router.back();
            return;
          }
        }

        const result = await analyzeCard(imageUri);

        let cardId: string;
        if (userId) {
          const saved = await saveCompleteScan({
            userId,
            frontImageUri: imageUri,
            aiResult: result,
          });
          cardId = saved.id;
        } else {
          await incrementDailyScans();
          const card: GradedCard = {
            id: Date.now().toString(),
            imageUri,
            result,
            timestamp: Date.now(),
            favorite: false,
          };
          await saveCard(card);
          cardId = card.id;
        }

        router.replace({
          pathname: "/(tabs)/(scan)/results",
          params: { cardId },
        });
      } catch (err: any) {
        console.error("Grading error:", String(err?.message ?? err));
        router.back();
      }
    })();
  }, [imageUri]);

  const spin = rotateAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ["0deg", "360deg"],
  });

  return (
    <View
      style={{
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        padding: 40,
        gap: 32,
        backgroundColor: T.bg,
      }}
    >
      <View style={{ position: "relative", alignItems: "center" }}>
        {imageUri && (
          <Image
            source={{ uri: imageUri }}
            style={{
              width: 200,
              height: 280,
              borderRadius: 12,
              borderCurve: "continuous",
            }}
            contentFit="cover"
          />
        )}
        <Animated.View
          style={{
            position: "absolute",
            top: -10,
            left: -10,
            right: -10,
            bottom: -10,
            borderRadius: 18,
            borderWidth: 2,
            borderColor: T.accent,
            opacity: pulseAnim,
          }}
        />
      </View>

      <View style={{ alignItems: "center", gap: 12 }}>
        <Animated.View style={{ transform: [{ rotate: spin }] }}>
          <View
            style={{
              width: 32,
              height: 32,
              borderRadius: 16,
              borderWidth: 3,
              borderColor: T.accent,
              borderTopColor: "transparent",
            }}
          />
        </Animated.View>
        <Text style={{ fontSize: 20, fontWeight: "700", color: T.text }}>
          Analyzing Card...
        </Text>
        <Text
          style={{
            fontSize: 14,
            color: T.textSecondary,
            textAlign: "center",
            lineHeight: 20,
          }}
        >
          Evaluating centering, corners, edges, and surface condition
        </Text>
      </View>
    </View>
  );
}
