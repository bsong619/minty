import { View, Text, ScrollView, Pressable } from "react-native";
import { useRouter } from "expo-router";
import { Image } from "expo-image";
import { T } from "@/lib/theme";

const LAST_UPDATED = "March 8, 2026";

export default function TermsScreen() {
  const router = useRouter();

  return (
    <View style={{ flex: 1, backgroundColor: T.bg }}>
      {/* Header bar */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 20,
          paddingTop: 56,
          paddingBottom: 16,
          borderBottomWidth: 1,
          borderBottomColor: T.borderSubtle,
        }}
      >
        <Text style={{ fontSize: 18, fontWeight: "700", color: T.text }}>
          Terms of Service
        </Text>
        <Pressable
          onPress={() => router.back()}
          hitSlop={12}
          style={{
            width: 30,
            height: 30,
            borderRadius: 15,
            backgroundColor: T.surface,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Image
            source="sf:xmark"
            style={{ width: 12, height: 12, tintColor: T.textSecondary }}
          />
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={{ padding: 24, gap: 20, paddingBottom: 60 }}
      >
        <Text style={{ fontSize: 12, color: T.textTertiary }}>
          Last updated: {LAST_UPDATED}
        </Text>

        <Section title="1. Acceptance of Terms">
          By downloading, installing, or using Minty ("the App"), you
          agree to be bound by these Terms of Service. If you do not agree, do
          not use the App.
        </Section>

        <Section title="2. Description of Service">
          Minty provides AI-powered predictions of Pokemon card grades.
          These predictions are estimates only and are not affiliated with or
          endorsed by PSA (Professional Sports Authenticator) or any official
          grading service. Predicted grades may differ from actual grades
          assigned by professional grading services.
        </Section>

        <Section title="3. User Accounts">
          You may use the App as a guest or create an account using email or
          third-party authentication (Google, Apple). You are responsible for
          maintaining the security of your account credentials.
        </Section>

        <Section title="4. Subscriptions & Payments">
          Minty offers free and paid subscription tiers. Free users
          receive 3 scans per day. Pro subscriptions are billed through Apple's
          App Store. Subscriptions auto-renew unless cancelled at least 24
          hours before the end of the current period. You can manage and cancel
          subscriptions in your device Settings → Apple ID → Subscriptions.
        </Section>

        <Section title="5. User Content">
          Images you upload for grading may be processed by third-party AI
          services. We do not claim ownership of your images. By using the
          service, you grant us a limited license to process your uploaded
          images for the purpose of providing grade predictions.
        </Section>

        <Section title="6. Disclaimer of Warranties">
          The App is provided "AS IS" without warranties of any kind. We do not
          guarantee the accuracy of grade predictions. Grade estimates should
          not be solely relied upon for purchasing or selling decisions.
        </Section>

        <Section title="7. Limitation of Liability">
          To the maximum extent permitted by law, Minty and its creators
          shall not be liable for any indirect, incidental, special, or
          consequential damages arising from your use of the App, including but
          not limited to financial losses from card buying or selling decisions
          based on our grade predictions.
        </Section>

        <Section title="8. Modifications">
          We reserve the right to modify these Terms at any time. Continued use
          of the App after changes constitutes acceptance of the new Terms.
        </Section>

        <Section title="9. Termination">
          We may terminate or suspend your account at any time for violations
          of these Terms. Upon termination, your right to use the App ceases
          immediately.
        </Section>

        <Section title="10. Contact">
          For questions about these Terms, contact us at
          support@minty.app.
        </Section>
      </ScrollView>
    </View>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <View style={{ gap: 8 }}>
      <Text style={{ fontSize: 15, fontWeight: "700", color: T.text }}>
        {title}
      </Text>
      <Text
        style={{
          fontSize: 14,
          color: T.textSecondary,
          lineHeight: 21,
        }}
      >
        {children}
      </Text>
    </View>
  );
}
