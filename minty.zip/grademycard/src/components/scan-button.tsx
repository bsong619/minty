import { Pressable, Text, View } from "react-native";
import { Image } from "expo-image";
import { T } from "@/lib/theme";

export default function ScanButton({
  icon,
  label,
  subtitle,
  onPress,
}: {
  icon: string;
  label: string;
  subtitle: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        flexDirection: "row",
        alignItems: "center",
        gap: 16,
        padding: 18,
        borderRadius: 16,
        borderCurve: "continuous",
        backgroundColor: pressed ? T.surfaceHover : T.surface,
        borderWidth: 1,
        borderColor: T.borderSubtle,
        opacity: pressed ? 0.9 : 1,
      })}
    >
      <View
        style={{
          width: 48,
          height: 48,
          borderRadius: 12,
          borderCurve: "continuous",
          backgroundColor: T.accentLight,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Image
          source={`sf:${icon}`}
          style={{ width: 24, height: 24, tintColor: T.accent }}
        />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 17, fontWeight: "600", color: T.text }}>
          {label}
        </Text>
        <Text
          style={{ fontSize: 13, color: T.textSecondary, marginTop: 2 }}
        >
          {subtitle}
        </Text>
      </View>
      <Image
        source="sf:chevron.right"
        style={{ width: 14, height: 14, tintColor: T.textTertiary }}
      />
    </Pressable>
  );
}
