import { DarkTheme, ThemeProvider as RNTheme } from "@react-navigation/native";
import { T } from "@/lib/theme";

const MintyTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    primary: T.accent,
    background: T.bg,
    card: T.surface,
    text: T.text,
    border: T.border,
    notification: T.accent,
  },
};

export function ThemeProvider(props: { children: React.ReactNode }) {
  return <RNTheme value={MintyTheme}>{props.children}</RNTheme>;
}
