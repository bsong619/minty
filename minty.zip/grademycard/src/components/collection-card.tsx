import { View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { GradedCard } from "@/lib/types";
import { getGradeColor } from "@/lib/grade-colors";
import { T } from "@/lib/theme";

export default function CollectionCard({
  card,
  onPress,
  width,
}: {
  card: GradedCard;
  onPress: () => void;
  width: number;
}) {
  const gradeColor = getGradeColor(card.result.overallGrade);

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        opacity: pressed ? 0.85 : 1,
        width,
        transform: [{ scale: pressed ? 0.97 : 1 }],
      })}
    >
      <View
        style={{
          borderRadius: 16,
          borderCurve: "continuous",
          backgroundColor: T.surface,
          overflow: "hidden",
          borderWidth: 1,
          borderColor: T.borderSubtle,
        }}
      >
        <Image
          source={{ uri: card.imageUri }}
          style={{ width: "100%", aspectRatio: 0.72 }}
          contentFit="cover"
        />
        <View style={{ padding: 10, gap: 4 }}>
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Text
              numberOfLines={1}
              style={{
                fontSize: 13,
                fontWeight: "600",
                color: T.text,
                flex: 1,
              }}
            >
              {card.result.cardName}
            </Text>
            <View
              style={{
                width: 28,
                height: 28,
                borderRadius: 14,
                backgroundColor: `${gradeColor}20`,
                borderWidth: 2,
                borderColor: gradeColor,
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "800",
                  color: gradeColor,
                  fontVariant: ["tabular-nums"],
                }}
              >
                {card.result.overallGrade}
              </Text>
            </View>
          </View>
          <Text style={{ fontSize: 11, color: T.textSecondary }}>
            {card.result.cardSet} · {card.result.cardNumber}
          </Text>
        </View>
        {card.favorite && (
          <View style={{ position: "absolute", top: 8, right: 8 }}>
            <Image
              source="sf:heart.fill"
              style={{ width: 18, height: 18, tintColor: T.danger }}
            />
          </View>
        )}
      </View>
    </Pressable>
  );
}
