import { View, Text } from "react-native";
import { getGradeColor } from "@/lib/grade-colors";
import { T } from "@/lib/theme";

export default function SubGradeBar({
  label,
  score,
  detail,
}: {
  label: string;
  score: number;
  detail?: string;
}) {
  const color = getGradeColor(Math.round(score));
  const percentage = (score / 10) * 100;

  return (
    <View style={{ gap: 6 }}>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "baseline",
        }}
      >
        <Text style={{ fontSize: 14, fontWeight: "600", color: T.text }}>
          {label}
        </Text>
        <View
          style={{ flexDirection: "row", alignItems: "baseline", gap: 4 }}
        >
          {detail && (
            <Text style={{ fontSize: 11, color: T.textSecondary }}>
              {detail}
            </Text>
          )}
          <Text
            style={{
              fontSize: 16,
              fontWeight: "700",
              color,
              fontVariant: ["tabular-nums"],
            }}
          >
            {score.toFixed(1)}
          </Text>
        </View>
      </View>
      <View
        style={{
          height: 6,
          borderRadius: 3,
          backgroundColor: T.surfaceHover,
          overflow: "hidden",
        }}
      >
        <View
          style={{
            height: "100%",
            width: `${percentage}%`,
            borderRadius: 3,
            backgroundColor: color,
          }}
        />
      </View>
    </View>
  );
}
