import { createClient } from "@supabase/supabase-js";
import * as Linking from "expo-linking";
import * as WebBrowser from "expo-web-browser";

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL ?? "";
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? "";

export const isSupabaseConfigured = !!(supabaseUrl && supabaseAnonKey);

function makeClient() {
  const isClient = typeof window !== "undefined";
  let storage: any = undefined;
  if (isClient) {
    storage = require("@react-native-async-storage/async-storage").default;
  }
  return createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      storage,
      autoRefreshToken: isClient,
      persistSession: isClient,
      detectSessionInUrl: false,
    },
  });
}

export const supabase = isSupabaseConfigured ? makeClient() : (null as any);

// ─── Auth helpers ──────────────────────────────────────────────

export async function ensureAuth(): Promise<string | null> {
  if (!isSupabaseConfigured) return null;
  const { data: { session } } = await supabase.auth.getSession();
  if (session?.user) return session.user.id;
  const { data, error } = await supabase.auth.signInAnonymously();
  if (error) throw error;
  return data.user!.id;
}

export async function signInWithEmail(email: string, password: string) {
  if (!supabase) throw new Error("Supabase is not configured.");
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data.user;
}

export async function signUpWithEmail(email: string, password: string) {
  if (!supabase) throw new Error("Supabase is not configured.");
  const redirectUrl = Linking.createURL("/login");
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { emailRedirectTo: redirectUrl },
  });
  if (error) throw error;
  return data.user;
}

export async function signOut() {
  if (!supabase) return;
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

// ─── Google OAuth ──────────────────────────────────────────────

export async function signInWithGoogle() {
  if (!supabase) throw new Error("Supabase is not configured.");
  const redirectUrl = Linking.createURL("/login");
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: "google",
    options: { redirectTo: redirectUrl, skipBrowserRedirect: true },
  });
  if (error) throw error;
  if (!data.url) throw new Error("No OAuth URL returned.");

  const result = await WebBrowser.openAuthSessionAsync(data.url, redirectUrl);
  if (result.type === "success" && result.url) {
    const url = new URL(result.url);
    const params = new URLSearchParams(
      url.hash ? url.hash.substring(1) : url.search.substring(1)
    );
    const accessToken = params.get("access_token");
    const refreshToken = params.get("refresh_token");
    if (accessToken && refreshToken) {
      const { data: sd, error: se } = await supabase.auth.setSession({
        access_token: accessToken,
        refresh_token: refreshToken,
      });
      if (se) throw se;
      return sd.user;
    }
  }
  throw new Error("Google sign-in was cancelled.");
}

// ─── Apple OAuth ───────────────────────────────────────────────

export async function signInWithApple() {
  if (!supabase) throw new Error("Supabase is not configured.");
  const redirectUrl = Linking.createURL("/login");
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: "apple",
    options: { redirectTo: redirectUrl, skipBrowserRedirect: true },
  });
  if (error) throw error;
  if (!data.url) throw new Error("No OAuth URL returned.");

  const result = await WebBrowser.openAuthSessionAsync(data.url, redirectUrl);
  if (result.type === "success" && result.url) {
    const url = new URL(result.url);
    const params = new URLSearchParams(
      url.hash ? url.hash.substring(1) : url.search.substring(1)
    );
    const accessToken = params.get("access_token");
    const refreshToken = params.get("refresh_token");
    if (accessToken && refreshToken) {
      const { data: sd, error: se } = await supabase.auth.setSession({
        access_token: accessToken,
        refresh_token: refreshToken,
      });
      if (se) throw se;
      return sd.user;
    }
  }
  throw new Error("Apple sign-in was cancelled.");
}

// ─── Password reset ────────────────────────────────────────────

export async function resetPassword(email: string) {
  if (!supabase) throw new Error("Supabase is not configured.");
  const redirectUrl = Linking.createURL("/login");
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: redirectUrl,
  });
  if (error) throw error;
}

export async function updatePassword(newPassword: string) {
  if (!supabase) throw new Error("Supabase is not configured.");
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  if (error) throw error;
}
