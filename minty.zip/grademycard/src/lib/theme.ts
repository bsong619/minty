/**
 * Unified dark theme for Minty.
 * Every screen uses these constants so the app has a single cohesive look.
 */

export const T = {
  // Backgrounds
  bg: "#0A0A0C",
  surface: "#141418",
  surfaceHover: "#1C1C22",
  surfaceElevated: "#1A1A20",
  card: "#161619",

  // Borders
  border: "#2A2A32",
  borderSubtle: "#222228",
  borderFocus: "#D32F2F",
  separator: "#2A2A3240",

  // Accent
  accent: "#D32F2F",
  accentDark: "#B71C1C",
  accentLight: "rgba(211,47,47,0.12)",
  accentGlow: "rgba(211,47,47,0.35)",

  // Text
  text: "#F5F5F7",
  textSecondary: "#8E8E93",
  textTertiary: "#636366",
  textInverse: "#FFFFFF",

  // Status
  success: "#34C759",
  warning: "#FF9500",
  danger: "#FF3B30",
  info: "#007AFF",
  gold: "#FFD700",

  // Gradients (for experimental_backgroundImage)
  accentGradient: "linear-gradient(135deg, #D32F2F, #B71C1C)",
  surfaceGradient: "linear-gradient(180deg, #141418, #0A0A0C)",
} as const;

/** Semantic aliases */
export const Colors = T;
