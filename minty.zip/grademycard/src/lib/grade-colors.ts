export function getGradeColor(grade: number): string {
  if (grade === 10) return "#FFD700"; // Gold
  if (grade === 9) return "#34C759"; // Green
  if (grade >= 7) return "#007AFF"; // Blue
  if (grade >= 5) return "#FF9500"; // Orange
  return "#FF3B30"; // Red
}

export function getConfidenceColor(
  confidence: "High" | "Medium" | "Low"
): string {
  switch (confidence) {
    case "High":
      return "#34C759";
    case "Medium":
      return "#FF9500";
    case "Low":
      return "#FF3B30";
  }
}
