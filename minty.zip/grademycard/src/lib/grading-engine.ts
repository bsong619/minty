import * as ImageManipulator from "expo-image-manipulator";
import { GradeResult } from "./types";

const GRADE_PROMPT = `You are an expert PSA card grader with 20+ years of experience grading Pokemon cards. Analyze this Pokemon card image and provide a detailed PSA grade prediction.

Return ONLY valid JSON in this exact format, with no markdown fences, no explanation, nothing else:
{
  "overallGrade": <integer 1-10>,
  "confidence": "<High|Medium|Low>",
  "subGrades": {
    "centering": <number 1-10, .5 increments ok>,
    "corners": <number 1-10, .5 increments ok>,
    "edges": <number 1-10, .5 increments ok>,
    "surface": <number 1-10, .5 increments ok>
  },
  "centeringDetail": {
    "leftRight": "<e.g. 52/48>",
    "topBottom": "<e.g. 51/49>",
    "passesThreshold": <true if within PSA 10 60/40 threshold on both axes>
  },
  "tips": [<1-3 specific, actionable tips to improve the grade>],
  "cardName": "<Pokemon name on card>",
  "cardSet": "<Set name, e.g. Base Set, Jungle, Evolving Skies>",
  "cardYear": "<4-digit year>",
  "cardNumber": "<card number e.g. 4/102>"
}

PSA grading criteria:
- Centering: PSA 10 requires 60/40 or better. PSA 9 requires 65/35.
- Corners: Look for whitening, dings, rounding, or fraying.
- Edges: Check all 4 edges for whitening, chipping, or roughness.
- Surface: Check for scratches, holo scratches, print lines, indentations, or staining.
Confidence: High=sharp image fills frame, Medium=some quality issues, Low=blurry/partial.
Set overallGrade as weighted average heavily influenced by the lowest sub-grade.`;

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const dataUrl = reader.result as string;
      resolve(dataUrl.split(",")[1]);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

async function getBase64(imageUri: string): Promise<string> {
  try {
    const result = await ImageManipulator.manipulateAsync(
      imageUri,
      [{ resize: { width: 600 } }],
      { compress: 0.7, format: ImageManipulator.SaveFormat.JPEG, base64: true }
    );
    return result.base64!;
  } catch {
    const res = await fetch(imageUri);
    const blob = await res.blob();
    return blobToBase64(blob);
  }
}

export async function analyzeCard(imageUri: string): Promise<GradeResult> {
  const base64 = await getBase64(imageUri);

  if (process.env.EXPO_OS === "web") {
    // Web: always use the API route — key lives server-side
    const res = await fetch("/api/grade", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ imageBase64: base64, mimeType: "image/jpeg" }),
    });
    if (!res.ok) throw new Error(`API route error ${res.status}`);
    return res.json();
  }

  // Native: direct call needs a client-side key
  const apiKey = process.env.EXPO_PUBLIC_ANTHROPIC_API_KEY;
  if (!apiKey) return mockGrade();

  // Native: call Anthropic directly (no CORS)
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 1024,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "image",
              source: { type: "base64", media_type: "image/jpeg", data: base64 },
            },
            { type: "text", text: GRADE_PROMPT },
          ],
        },
      ],
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    console.error("Anthropic error:", err);
    throw new Error(`Anthropic API error ${response.status}`);
  }

  const data = await response.json();
  const text: string =
    data.content?.[0]?.type === "text" ? data.content[0].text : "";
  const clean = text.replace(/^```[a-z]*\n?/i, "").replace(/\n?```$/i, "").trim();
  const raw = JSON.parse(clean);

  // Coerce nulls — Claude returns null when the image isn't a recognisable card
  const num = (v: unknown, fallback: number) =>
    typeof v === "number" && !isNaN(v) ? v : fallback;

  const result: GradeResult = {
    overallGrade: Math.min(10, Math.max(1, Math.round(num(raw.overallGrade, 1)))),
    confidence: raw.confidence ?? "Low",
    subGrades: {
      centering: num(raw.subGrades?.centering, 1),
      corners: num(raw.subGrades?.corners, 1),
      edges: num(raw.subGrades?.edges, 1),
      surface: num(raw.subGrades?.surface, 1),
    },
    centeringDetail: {
      leftRight: raw.centeringDetail?.leftRight ?? "N/A",
      topBottom: raw.centeringDetail?.topBottom ?? "N/A",
      passesThreshold: raw.centeringDetail?.passesThreshold ?? false,
    },
    tips: Array.isArray(raw.tips) ? raw.tips.filter(Boolean) : [],
    cardName: raw.cardName ?? "Unknown Card",
    cardSet: raw.cardSet ?? "Unknown Set",
    cardYear: raw.cardYear ?? "????",
    cardNumber: raw.cardNumber ?? "??/??",
  };
  return result;
}

function mockGrade(): GradeResult {
  return {
    overallGrade: 8,
    confidence: "Low",
    subGrades: { centering: 8, corners: 7.5, edges: 8.5, surface: 8 },
    centeringDetail: {
      leftRight: "55/45",
      topBottom: "53/47",
      passesThreshold: false,
    },
    tips: ["Add EXPO_PUBLIC_ANTHROPIC_API_KEY to .env to enable real AI grading."],
    cardName: "Unknown Card",
    cardSet: "Unknown Set",
    cardYear: "????",
    cardNumber: "??/??",
  };
}
