## Principles

- Target iOS, Android, web.
- Install dependencies with `bunx expo add <package>`
- Use `expo-image` for images and icons.
- Routes go in `src/app/`, components go in `src/components/`
- Use kebab-case for file names (e.g., `user-card.tsx`)

## Design Preferences

- Dark theme only — all colors from `src/lib/theme.ts`
- Accent: #D32F2F (red)
- Background: #0A0A0C
- Surfaces: #141418
- Use `T` import for all color references

## Components

- `src/components/scan-button.tsx` — action buttons on scan screen
- `src/components/collection-card.tsx` — card grid items
- `src/components/grade-badge.tsx` — circular PSA grade display
- `src/components/sub-grade-bar.tsx` — progress bars for sub-grades
- `src/components/auth-provider.tsx` — auth context with Supabase
- `src/components/theme-provider.tsx` — forced dark navigation theme
